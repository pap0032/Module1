![alt text](https://github.com/ajariwala1/HelloWorld/blob/main/Docs/banner_au.png?raw=true)


:stop_sign: `Incomplete` <br/>
:bangbang: `Skeleton Project`

# HelloWorld

This is a simple Hello World application. It shows "Hello, AU!" text with the AU logo on the home screen.
This is a skeleton project that includes all assets you need to build the application.

## Getting Started

Clone the project and see the lecture video on Canvas under Module 1 for instructions. <br/>
See the completed HelloWorld application here: <br/>
https://github.com/ajariwala1/HelloWorld_Completed

## What you will learn

- Clone an existing project from GitHub.
- Get an overview of XCode.
- Add design components to your app.
- Import image assets to your app.
- Test and debug your app.
